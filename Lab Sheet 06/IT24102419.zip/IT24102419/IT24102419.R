setwd("C:\\Users\\ASUS\\Desktop\\IT24102419")

n <- 50
p <- 0.85

cat("X ~ Binomial(50, 0.85)\n")

prob_Q1 <- pbinom(46, size=n, prob=p, lower.tail=FALSE)
cat("P(X >= 47) =", prob_Q1, "\n\n")

lambda <- 12

cat("X = number of calls received in one hour\n")

cat("X ~ Poisson(12)\n")

prob_Q2 <- dpois(15, lambda=lambda)
cat("P(X = 15) =", prob_Q2, "\n")